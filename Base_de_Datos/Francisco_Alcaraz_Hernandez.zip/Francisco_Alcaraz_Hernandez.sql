#DROP DATABASE biblioteca;

CREATE DATABASE biblioteca;

USE biblioteca;

CREATE TABLE libros(
    id_libro INT AUTO_INCREMENT,
    titulo VARCHAR(100) NOT NULL,
    tema VARCHAR(50) NOT NULL,
    n_paginas INT,
    prestado BOOLEAN NOT NULL,
    fec_ult_res DATE NOT NULL,
    PRIMARY KEY(id_libro)
);

CREATE TABLE autores(
    id_autor INT AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    dni CHAR(9) UNIQUE NOT NULL,
    tema1 VARCHAR(100),
    tema2 VARCHAR(100),
    PRIMARY KEY(id_autor)
);

CREATE TABLE libros_autores(
    id_libro_autor INT AUTO_INCREMENT,
    fk_id_libro INT,
    fk_id_autor INT,
    PRIMARY KEY(id_libro_autor),
    FOREIGN KEY(fk_id_libro) REFERENCES libros(id_libro),
    FOREIGN KEY(fk_id_autor) REFERENCES autores(id_autor)
);
