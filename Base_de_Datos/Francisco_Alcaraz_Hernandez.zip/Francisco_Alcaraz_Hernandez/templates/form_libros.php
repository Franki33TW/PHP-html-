<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="mt-4">Inserta un libro</h2>
      <hr>
      <form method="post" action="scripts/alta_libros.php">
        <div class="form-group">
          <label for="titulo">Título</label>
          <input type="text" name="titulo" class="form-control">
        </div>
        <div class="form-group">
          <label for="tema">Tema</label>
          <input type="text" name="tema" class="form-control">
        </div>
        <div class="form-group">
          <label for="n_paginas">Número de páginas</label>
          <input type="int" name="n_paginas" class="form-control">
        </div>
        <div class="form-group">
          <label for="prestado">Prestado (NO = 0) (SI = 1)</label>
          <input type="boolean" name="prestado" class="form-control">
        </div>
        <div class="form-group">
          <label for="fec_ult_res">Fecha de la última reserva</label>
          <input type="date" name="fec_ult_res" class="form-control">
        </div>
        <div class="form-group">
          <input type="submit" name="boton_libros" class="btn btn-primary" value="Registrar">
        </div>
      </form>
      </form>
    </div>
  </div>
</div>
