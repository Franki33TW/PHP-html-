<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="mt-4">Inserta el autor de cada libro</h2>
      <hr>
      <form method="post" action="scripts/alta_libros_autores.php">
        <div class="form-group">
          <label for="fk_id_libro">ID del libro</label>
          <input type="int" name="fk_id_libro" class="form-control">
        </div>
        <div class="form-group">
          <label for="fk_id_autor">ID del autor</label>
          <input type="int" name="fk_id_autor" class="form-control">
        </div>
        <div class="form-group">
          <input type="submit" name="boton_libros_autores" class="btn btn-primary" value="Registrar">
        </div>
      </form>
      </form>
    </div>
  </div>
</div>
