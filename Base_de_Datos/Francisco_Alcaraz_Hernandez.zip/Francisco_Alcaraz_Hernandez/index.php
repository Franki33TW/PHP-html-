<?php include "templates/header.php"; ?>
<?php include "templates/form_libros.php"; ?>
<?php include "templates/form_autores.php"; ?>
<?php include "templates/form_libros_autores.php"; ?>
<?php include "templates/footer.php"; ?>