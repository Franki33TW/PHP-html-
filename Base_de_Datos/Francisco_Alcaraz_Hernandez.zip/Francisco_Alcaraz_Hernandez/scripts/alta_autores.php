<?php
if (isset($_POST['boton_autores'])) {
  $resultado = [
    'error' => false,
    'mensaje' => 'El autor ' . $_POST['nombre'] . ' ha sido agregado con éxito'
  ];
  $config = include 'config_DB.php';

  try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], $config['db']['pass'], $config['db']['options']);

    $autor = array(
      "nombre"   => $_POST['nombre'],
      "apellidos" => $_POST['apellidos'],
      "dni"    => $_POST['dni'],
      "tema1"     => $_POST['tema1'],
      "tema2"     => $_POST['tema2']
    );

    $consultaSQL = "INSERT INTO autores (nombre, apellidos, dni, tema1, tema2)";
    $consultaSQL .= "values (:" . implode(", :", array_keys($autor)) . ")";

    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute($autor);

  } catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
  }
}
?>

<?php include "../templates/header.php"; ?>

<?php
if (isset($resultado)) {
  ?>
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-<?= $resultado['error'] ? 'danger' : 'success' ?>" role="alert">
          <?= $resultado['mensaje'] ?>
        </div>
      </div>
    </div>
  </div>
  <?php
}

?>
<?php include "../templates/footer.php"; ?>
