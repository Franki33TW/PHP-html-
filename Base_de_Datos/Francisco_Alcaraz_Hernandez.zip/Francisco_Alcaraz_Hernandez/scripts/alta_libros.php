<?php
if (isset($_POST['boton_libros'])) {
  $resultado = [
    'error' => false,
    'mensaje' => 'El libro ' . $_POST['titulo'] . ' ha sido agregado con éxito'
  ];
  $config = include 'config_DB.php';

  try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], $config['db']['pass'], $config['db']['options']);

    $libro = array(
      "titulo" => $_POST['titulo'],
      "tema" => $_POST['tema'],
      "n_paginas" => $_POST['n_paginas'],
      "prestado" => $_POST['prestado'],
      "fec_ult_res" => $_POST['fec_ult_res']
    );

    $consultaSQL = "INSERT INTO libros (titulo, tema, n_paginas, prestado, fec_ult_res)";
    $consultaSQL .= "values (:" . implode(", :", array_keys($libro)) . ")";

    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute($libro);

  } catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
  }
}
?>

<?php include "../templates/header.php"; ?>

<?php
if (isset($resultado)) {
  ?>
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-<?= $resultado['error'] ? 'danger' : 'success' ?>" role="alert">
          <?= $resultado['mensaje'] ?>
        </div>
      </div>
    </div>
  </div>
  <?php
}

?>
<?php include "../templates/footer.php"; ?>
