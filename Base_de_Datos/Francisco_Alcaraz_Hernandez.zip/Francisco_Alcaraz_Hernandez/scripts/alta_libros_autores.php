<?php
if (isset($_POST['boton_libros_autores'])) {
  $resultado = [
    'error' => false,
    'mensaje' => 'El autor del libro ha sido agregado con éxito'
  ];
  $config = include 'config_DB.php';

  try {
    $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'];
    $conexion = new PDO($dsn, $config['db']['user'], $config['db']['pass'], $config['db']['options']);

    $libro_autor = array(
      "fk_id_libro" => $_POST['fk_id_libro'],
      "fk_id_autor" => $_POST['fk_id_autor']
    );

    $consultaSQL = "INSERT INTO libros_autores (fk_id_libro, fk_id_autor)";
    $consultaSQL .= "values (:" . implode(", :", array_keys($libro_autor)) . ")";

    $sentencia = $conexion->prepare($consultaSQL);
    $sentencia->execute($libro_autor);

  } catch(PDOException $error) {
    $resultado['error'] = true;
    $resultado['mensaje'] = $error->getMessage();
  }
}
?>

<?php include "../templates/header.php"; ?>

<?php
if (isset($resultado)) {
  ?>
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-<?= $resultado['error'] ? 'danger' : 'success' ?>" role="alert">
          <?= $resultado['mensaje'] ?>
        </div>
      </div>
    </div>
  </div>
  <?php
}

?>
<?php include "../templates/footer.php"; ?>
